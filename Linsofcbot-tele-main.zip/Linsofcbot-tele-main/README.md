# 🤖 Linsofcbot-Tele

Bot Telegram berbasis **Node.js** yang terintegrasi dengan **Google Gemini AI**.  
Fungsinya bisa menjawab pesan teks, menganalisis gambar, menampilkan informasi terkini, hingga memberikan motivasi.  


---

## ✨ Fitur
```text
/start      - Memulai interaksi dengan bot
/help       - Menampilkan daftar command
/infogempa  - Info gempa terbaru dari BMKG
/news       - Berita terbaru Indonesia
/gemini     - Chat dengan Google Gemini AI (support teks + gambar)
/random     - Quote atau kata bijak acak
```

---

## 📦 Instalasi

### 1. Clone repository
```bash
git clone https://github.com/Linsofc/Linsofcbot-tele.git
cd Linsofcbot-tele
```

### 2. Install dependencies
```bash
npm install
```

### 3. Setup `.env`
Buat file `.env` di root project, lalu isi:

```env
TELEGRAM_TOKEN = isi_dengan_token_dari_BotFather
GOOGLE_API_KEY = isi_dengan_api_key_dari_ai_studio
```

- **TELEGRAM_TOKEN** → ambil dari [@BotFather](https://t.me/BotFather)  
- **GOOGLE_API_KEY** → buat di [Google AI Studio](https://aistudio.google.com/apikey)

### 4. Jalankan bot
```bash
npm start
```

---

## 📂 Struktur Project
```
Linsofcbot-tele/
│── App/
│   ├── artificial_intellegence.js   # koneksi Gemini
│   ├── callback_query.js   # get data message
│   ├── Linsbot.js   # class
│   ├── message.js        # handler pesan telegram
│── Libs/
│   ├── constant.js        # constanta message
│   ├── functions.js   # functions
│── utils/
│   ├── logger.js        # handle log
│── .env                  # konfigurasi token & API key
│── package.json        # package
│── index.js              # entry point
```



---

## ⚠️ Catatan
- Jangan commit `.env` ke GitHub (sudah di-ignore otomatis)
- API Key punya limit, jangan dibagi sembarangan
- Pastikan Node.js versi **18+**

---

## 📜 Lisensi
MIT License © 2025 [Lins Official](https://github.com/Linsofc)
