const { reply, getRandomElement } = require('../libs/functions');
const logger = require('../utils/logger')

module.exports = async (bot, msg) => {
    const chatId = msg.message.chat.id;
    const data = msg.data;
    const username = msg.from.username;
    // console.log(msg)
    switch (data){
        case 'quote': {
            logger('green', `[${username}]`, `${data}`)
            try {
                const github = "https://raw.githubusercontent.com/Linsofc/Api-free-Lins-MD/refs/heads/main/db/random/quotes.json"
                const url = fetch(github)
                const result = await url.then(res => res.json())
                const quote = getRandomElement(result)
                reply(bot, chatId, quote.quote)
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${data}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }
        case 'katabijak': {
            logger('green', `[${username}]`, `${data}`)
            try {
                const github = "https://raw.githubusercontent.com/Linsofc/Api-free-Lins-MD/refs/heads/main/db/random/bijak.json"
                const url = fetch(github)
                const result = await url.then(res => res.json())
                const bijak = getRandomElement(result)
                reply(bot, chatId, bijak.bijak)
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${data}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }
        case 'fakta': {
            try {
                const github = "https://raw.githubusercontent.com/Linsofc/Api-free-Lins-MD/refs/heads/main/db/random/fakta.json"
                const url = fetch(github)
                const result = await url.then(res => res.json())
                const fakta = getRandomElement(result)
                reply(bot, chatId, fakta.fakta)
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${data}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }
        case 'motivasi': {
            try {
                const github = "https://raw.githubusercontent.com/Linsofc/Api-free-Lins-MD/refs/heads/main/db/random/motivasi.json"
                const url = fetch(github)
                const result = await url.then(res => res.json())
                const motivasi = getRandomElement(result)
                reply(bot, chatId, motivasi.motivasi)
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${data}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }
    }
}