const TelegramBot = require('node-telegram-bot-api');
const { startMessage } = require('../libs/constatnt');
class Linsbot extends TelegramBot {
    constructor(token, options) {
        super(token, options);
    }

    getMessage(){
        this.on('message', (msg) => {
            require('./message')(this, msg);
        });
    }

    callBackQuery(){
        this.on('callback_query', (msg) => {
            require('./callback_query')(this, msg);
        });
    }

    klikStart(){
        this.onText(/\/start/, (msg) => {
            const chatId = msg.chat.id;
            this.sendMessage(chatId, startMessage(msg.from.first_name));
        });
    }
}

module.exports = Linsbot;