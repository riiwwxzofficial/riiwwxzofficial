const genai = require("@google/genai");
const axios = require("axios");
const GoogleGenAI = genai.GoogleGenAI;

async function geminiAi(apikey, msg) {
  try {
    const ai = new GoogleGenAI({
      apiKey: apikey,
    });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
    //   model: "gemini-2.5-pro",
      contents: msg,
    });

    return response.text
  } catch (err) {
    console.error("Error:", err);
    return "Server Sedang Error"
  }
}


async function geminiAiImage(apikey, msg, fileUrl) {
  try {
    // Download file Telegram
    const res = await axios.get(fileUrl, { responseType: "arraybuffer" });
    const buffer = Buffer.from(res.data, "binary");
    const base64 = buffer.toString("base64");

    const ai = new GoogleGenAI({ apiKey: apikey });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            { text: msg },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64,
              },
            },
          ],
        },
      ],
    });

    return response.candidates?.[0]?.content?.parts?.[0]?.text || "Tidak ada jawaban";
  } catch (err) {
    console.error("Error:", err.response?.data || err);
    return "Server Sedang Error";
  }
}

module.exports = { geminiAi, geminiAiImage };
