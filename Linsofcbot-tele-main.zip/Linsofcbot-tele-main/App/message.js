const { reply, replyMarkup, sendImage, getRandomElement, ucapanWaktu, getTelegramFileUrl } = require('../libs/functions');
const { helpMessage } = require('../libs/constatnt');
const { geminiAi, geminiAiImage }  = require('./artificial_intellegence')
const logger = require('../utils/logger')
require('dotenv').config()

module.exports = async (bot, msg) => {
    const chatId = msg.chat.id;
    const text = msg?.text;
    const command = text?.split(' ')[0].toLowerCase();
    const args = text ? text.split(' ').slice(1) : [];
    const q = args.join(' ');
    const photo = msg.photo ? msg.photo[0].file_id : null;
    const firstName = msg.from.first_name;
    const lastName = msg.from?.last_name;
    const username = msg.from.username;
    // console.log(msg)

    switch (command) {
        case '/help':
            logger('green', `[${username}]`, `${text}`)
            reply(bot, chatId, helpMessage);
            break;
        case '/infogempa': {
            logger('green', `[${username}]`, `${text}`)
            try {
                const url = 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
                const callApi = fetch(url)
                const result = await callApi.then(res => res.json());
                const { Tanggal, Jam, Lintang, Bujur, Magnitude, Kedalaman, Wilayah, Potensi, Shakemap } = result.Infogempa.gempa;
                const imgUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${Shakemap}`;

                const message = `Info Gempa Terbaru:\n` +
                    `Tanggal: ${Tanggal}\n` +
                    `Jam: ${Jam}\n` +
                    `Lintang: ${Lintang}\n` +
                    `Bujur: ${Bujur}\n` +
                    `Magnitude: ${Magnitude}\n` +
                    `Kedalaman: ${Kedalaman}\n` +
                    `Wilayah: ${Wilayah}\n` +
                    `Potensi: ${Potensi}\n`;
                
                sendImage(bot, chatId, imgUrl, message);
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${text}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }

        case '/news': {
            logger('green', `[${username}]`, `${text}`)
            try {
                const url = 'https://jakpost.vercel.app/api/category/indonesia';
                const callApi = fetch(url);
                const result = await callApi.then(res => res.json());
                const maxNews = 2;

                for (let i = 0; i < maxNews; i++) {
                    const { title, image, headline } = getRandomElement(result.posts);
                    sendImage(bot, chatId, image, `*${title}*\n\n_${headline}_`, 'Markdown' );
                }
            } catch (error) {
                logger('red', `ERROR => [${username}]`, `${text}\n${error}`)
                reply(bot, chatId, 'Server Sedang Error')
            }
            break;
        }

        case '/gemini': {
            logger('green', `[${username}]`, `${text}`)
            if (!q) return reply(bot, chatId, `Example: ${command} perintah (support image)`)
            if (photo) {
                console.log('meriksa url')
                let url = await getTelegramFileUrl(process.env.TELEGRAM_TOKEN, photo)
                console.log(url)
                let ress = await geminiAiImage(process.env.GOOGLE_API_KEY, msg.caption, url)
                reply(bot, chatId, ress)
            } else {
                let ress = await geminiAi(process.env.GOOGLE_API_KEY, q)
                reply(bot, chatId, ress)
            }
            break;
        }
        
        case '/random': {
            logger('green', `[${username}]`, `${text}`)
            let teks = `<b>🌟 Hello! Kak ${firstName} ${ucapanWaktu()}</b>\nIni adalah <b>random text</b> untukmu hari ini ✨\nSilakan pilih salah satu kategori di bawah 👇`;


            let button = [
                [
                    { text: '💡 Quote', callback_data: 'quote' },
                    { text: '📖 Kata Bijak', callback_data: 'katabijak' },
                ],
                [
                    { text: '🤯 Fakta Unik', callback_data: 'fakta' },
                    { text: '🚀 Motivasi', callback_data: 'motivasi' },
                ],
            ];
            replyMarkup(bot, chatId, teks, button)
            break;
        }
    }

    if (photo !== null){
        if (msg.caption.split(' ')[0].toLowerCase() === '/gemini') {
            reply(bot, chatId, 'Sedang Mendeteksi Gambar...')
            logger('green', `[${username}]`, `${msg.caption}`)
            let url = await getTelegramFileUrl(process.env.TELEGRAM_TOKEN, photo)
            let ress = await geminiAiImage(process.env.GOOGLE_API_KEY, msg.caption, url)
            reply(bot, chatId, ress)
        }
    }
}