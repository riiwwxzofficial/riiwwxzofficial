const getRandomElement = require('../libs/functions').getRandomElement;
const logger = (color, title, message) => {
    const date = new Date();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");

    const colors = {
        black: 0,
        red: 1,
        green: 2,
        yellow: 3,
        blue: 4,
        magenta: 5,
        cyan: 6,
        white: 7
    };

    const code = colors[color] ?? 7; 
    const time = `\x1B[33m[${hours}:${minutes}]\x1B[0m`;

    console.log(`${time}\n\x1B[3${code}m${title}\x1B[0m\n\x1B[1;3;4${getRandomElement([1, 2, 3, 4, 5, 6])}mMessage:\x1B[0m\x20${message}\n`);
};

module.exports = logger
