const Linsbot = require('./App/Linsbot');
const dotenv = require('dotenv');
dotenv.config();
const token = process.env.TELEGRAM_TOKEN;
const bot = new Linsbot(token, { polling: true });

const Main = () => {
    bot.klikStart();
    bot.getMessage();
    bot.callBackQuery();
}

Main()